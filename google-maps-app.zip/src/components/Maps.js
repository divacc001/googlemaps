import React from 'react';
import { GoogleMap, LoadScript } from '@react-google-maps/api';
import styled from 'styled-components';

const containerStyle = {
  width: '800px',
  height: '400px'
};

const center = {
  lat: -3.745,
  lng: -38.523
};

const MapWrapper = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh; // This makes the map vertically centered
`;

function MyComponent() {
  return (
    <LoadScript
      googleMapsApiKey="AIzaSyB9xosaOMA9Smf2HvX42V-9rKRJfIXaaOY"
    >
      <MapWrapper>
        <GoogleMap
          mapContainerStyle={containerStyle}
          center={center}
          zoom={10}
        >
        </GoogleMap>
      </MapWrapper>
    </LoadScript>
  )
}

export default React.memo(MyComponent);
