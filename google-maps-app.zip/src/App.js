
import Maps from './components/Maps';

function App() {
  return (
    <div>
      <Maps/>
    </div>
  );
}

export default App;
